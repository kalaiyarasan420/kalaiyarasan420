import kg from "../assets/download (6).png";
import ELCELogo from "../assets/ELCE.jpg";
import kmch from "../assets/download.png";
import snr from "../assets/download (1).png";
import medwin from "../assets/MedwinLogo.jpg";
import kongunad from "../assets/KongunadLogo.jpg";
import pristyn from "../assets/download (8).png";
import ganga from "../assets/download (2).png";
import {BrowserRouter, Routes, Route, Link} from 'react-router-dom';
import { FormControlLabel, Rating } from "@mui/material";
 import rendered from "../pages/Rendered1";
export const MenuList = [

 {
    
    name:<Link to="/KMCH">KMCH Hospital</Link>,
    image: kmch,
    address:<h3>99, Avanashi Road, Coimbatore, Tamil Nadu - 641014.
    <br></br>
    <FormControlLabel control={<Rating name="read-only" value={4.4} precision={0.1} readOnly />} label="  4.4"/>
   
    
    </h3>
     },
     {
       name:<Link to="/ELCE">ELCE</Link>,
       image: ELCELogo,
       address: <h3>Avinashi Road, Kalluri Nagar, Coimbatore, Tamil Nadu 641004.
    <br></br>
    <FormControlLabel control={<Rating name="read-only" value={4.4} precision={0.1} readOnly />} label="  4.3"/>
    </h3>
      },
      {
        name:<Link to="/KG">KG Hospital</Link>,
       
        image: kg,
        address: <h3>5, Government Arts College Road, Coimbatore, Tamil Nadu 641018.
    <br></br>
    <FormControlLabel control={<Rating name="read-only" value={4.4} precision={0.1} readOnly />} label="  4.2"/>
    </h3>
      },
      {
        name:<Link to="/KN">KonguNadu Hospital</Link>,
      
        image: kongunad,
        address: <h3> 395, Sarojini Naidu Road, Sidhapudur, Coimbatore, Tamil Nadu 641004.
    <FormControlLabel control={<Rating name="read-only" value={4.4} precision={0.1} readOnly />} label="  4.0"/>
    <br></br>
    </h3>
      },
        {
          name:<Link to="/MEDWIN">Medwin Hospital</Link>,
      
          image: medwin,
          address: <h3>No. 42, Opposite Stock Exchange, <br/> Near Alvernia School, Trichy Rd,<br/>
          Coimbatore, Tamil Nadu 641005.
          <br></br>
    <FormControlLabel control={<Rating name="read-only" value={4.4} precision={0.1} readOnly />} label="  3.9"/></h3>
        },
        {
          name:<Link to="/SNR">Sri Ramakrishna Hospital</Link>,
        
          image: snr,
          address: <h3>395, Sarojini Naidu Road, Sidhapudur, Coimbatore, Tamil Nadu 641004.
          <br></br>
    <FormControlLabel control={<Rating name="read-only" value={4.4} precision={0.1} readOnly />} label="  3.9"/></h3>
        },
      ];