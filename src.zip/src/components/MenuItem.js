import React from "react";

function MenuItem({ image, name, address}) {
  return (
    <div className="menuItem">
      <div className="pic" style={{ backgroundImage: `url(${image})` }}> </div>
      <h1> {name} </h1>
      <p> {address} </p>
    

    </div>
  );
}

export default MenuItem;