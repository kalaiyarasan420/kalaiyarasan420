import React from "react";
import InstagramIcon from '@mui/icons-material/Instagram';
import TwitterIcon from '@mui/icons-material/Twitter';
import FacebookIcon from '@mui/icons-material/Facebook';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import "../styles/Footer.css";

function Footer() {
  return (
    <div className="footer">
    <div className="subs">Get Connected in our Social Media Handles!
    
   
            {/* <input className="subsmail" name="email" placeholder="  Email address" type="text" /> */}
    </div>
    
      <div className="socialMedia">
      <a href="https://instagram.com/_hak_mg?igshid=YmMyMTA2M2Y=">
        
        <InstagramIcon />
         
        

      </a>
      <a href="https://twitter.com/_hak_mg?t=muDQQu0U4PcIkAPcBHk6CQ&s=08" >
        
      <TwitterIcon />
         
        

      </a>
      <a href="https://www.facebook.com/profile.php?id=100087978027236&mibextid=ZbWKwL">
        
      <FacebookIcon />
         
        

      </a>
      <a href="https://instagram.com/_hak_mg?igshid=YmMyMTA2M2Y=">
        
      <LinkedInIcon />
         
        

      </a>
        
        
        
      </div>
      <p> &copy; Copyright 2019-2021 KAPPAAN.com. All Rights Reserved.</p>
    </div>
  );
}

export default Footer;