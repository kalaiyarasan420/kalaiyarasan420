import React, { useState } from "react";
import Logo from "../assets/Logo3.png";
import { Link } from "react-router-dom";
import HomeIcon from '@mui/icons-material/Home';
import ReorderIcon from '@mui/icons-material/Reorder';
import LogoutIcon from '@mui/icons-material/Logout';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import RateReviewIcon from '@mui/icons-material/RateReview';
import SearchIcon from '@mui/icons-material/Search';

import "../styles/Navbar.css";

function Navbar() {
  const [openLinks, setOpenLinks] = useState(false);

  const toggleNavbar = () => {
    setOpenLinks(!openLinks);
  };
  return (
    <div className="navbar">
      <div className="leftSide" id={openLinks ? "open" : "close"}>
      <br></br>
      <Link to="/"> 
        <img className="photo" src={Logo} /></Link>
        <div className="hiddenLinks">
          <Link to="/"> Home </Link>
          <Link to="/profile"> Profile </Link>
          {/* <Link to="/menu"> Menu </Link> */}
          <Link to="/search"> Search </Link>
          <Link to="/contact"> Contact </Link>
          <Link to="/login"> Login </Link>
          
        </div>
      </div>
      <div className="rightSide">
        <Link to="/"> <HomeIcon/><span title="Home"> Home</span></Link>
          <Link to="/profile"><AccountCircleIcon/><span title="Profile"> Profile</span></Link>
        {/* <Link to="/menu"> Menu </Link> */}
        <Link to="/search"><SearchIcon/><span  title="Search"> Search</span></Link>
        <Link to="/contact"><RateReviewIcon/><span  title="Enquiry"> Enquiry</span></Link>

          <Link to="/login"> <LogoutIcon/><span title="Logout"> Logout</span></Link>
        <button onClick={toggleNavbar}>
          <ReorderIcon />
        </button>
        
      </div>
  
    </div>
    
  );
}

export default Navbar;