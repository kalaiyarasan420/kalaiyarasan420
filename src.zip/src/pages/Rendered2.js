import React from "react";
import { Link } from "react-router-dom";
import { Rating } from "@mui/material";
import { FormControlLabel } from "@mui/material";
import ELCELogo from "../assets/ELCE1.png";
import ForwardIcon from '@mui/icons-material/Forward';
import "../styles/Rendered1.css";

function Rendered() {
  return (
    <div className="home" 
    // style={{ backgroundImage: `url(${BannerImage})`  }}
    >
      <div className="headerContainer">
      <div>
      <img className="photo" src={ELCELogo} />
        
        <h3 className="address">414, Bharathiyar Rd, opp. to Women's Polytechnic,
<br></br>Siddhapudur, Gopalapuram, New Siddhapudur,
<br></br>
Coimbatore, Tamil Nadu 641044.
        </h3>
        <FormControlLabel control={<Rating name="half-rating" defaultValue={4.9} precision={0.1}/>} label="  4.9"/>
       
        </div>
        <div>
        <h2 className="overview"> <ForwardIcon/> Overview</h2>

        <p>⁜ ELCE is only in the 19th century that medicine made rapid progress.</p>
        <p>⁜ ELCE specializes in Laparoscopic surgeries, Therapeutic Endoscopies and also 24-hr/day-care laparoscopic solutions.</p>
        <p>⁜ Free Endoscopy Screening has been conducted for over 6700 individuals in a span of 30 months.</p>
        <p>⁜ Successfully trained hundreds of surgeons across the country.</p>
        <p>⁜ Awarded the prestigious American Fellowships FACS and FICS.</p>
        <p>⁜ Round the clock emergency care and ambulance facility.</p>
        </div>
        <div>
        <h2 className="overview"> <ForwardIcon/> Applicable Insurance</h2>
        <p>⁜ 24/7 Emergency Services</p>
        <p>⁜ Ambulance costs</p>
        <p>⁜ In-Patient Hospitalization costs</p>
        <p>⁜ Pre-Hospitalization costs</p>
        <p>⁜ Post-Hospitalization costs</p>
        <p>⁜ Day Care costs</p>
        <h3 className="overview"> <ForwardIcon/> Special Surgeries</h3>
        <p>⁜ HERNIA TREATMENT.</p>
        <p>⁜ Uterus Removal Surgery.</p>
        <p>⁜ ELCE Gastroscopy.</p>
        </div>
        <a href="https://elceclinics.com/appointment-book/">
        
        <button> Make An Appointment
         
         </button>

      </a>
        <br></br>
        <br></br>
        <br></br>
      </div>
    </div>
  );
}

export default Rendered;