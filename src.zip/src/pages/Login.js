import React, { Component } from 'react'
import { Link } from "react-router-dom";
// import { Typography, TextField, Grid, RadioGroup,  FormControl, FormLabel, FormControlLabel, Radio, Button } from '@mui/material';
import { Typography,  Grid, Button, Card, FormControlLabel ,Checkbox, TextField} from '@mui/material';
import logo from "../assets/Logo.png";
import "../styles/Login.css";
import GoogleIcon from '@mui/icons-material/Google';
export default class Signup extends Component {
    Grid={backgroundColor:"#EF9FEF"}
    Typo={fontWeight:"Bold",color:"#800080"}
    Buttonstyle={backgroundColor:"#800080", width:"100px", height:"50px"}
    cardstyle={padding:"45px", width:700,marginRight:"30px",textAlign:"center",height:"900"}
    Checkbox={color:"#800080"}
    imgstyle={width:400,paddingLeft:"15px",marginRight:"600px"}
    google={fontWeight:"Bold"}
    Linkstyle={color:"white"}
  render() {
    return (
<div className='background'>
        <Grid align="center" style={this.Grid}>
        <Card  elevation={0} style={this.cardstyle} >
        <img className="photo" src= {logo} style={this.imgstyle} alt="not found"/>
        <br/>
        <br/>
        <Typography variant="h4" align="left"style={this.Typo}>Welcome Back</Typography>
        <h3 align="left">we abbreviate for your care!</h3>
        <br/>
        <button className='signin' align="center" height="65px" color='white' backgroundColor="purple" style={this.google}><GoogleIcon style={{height:"15px"} }></GoogleIcon> Sign in with GOOGLE</button>
        <br/>
        <h4 align="center">-------------Or Sign in with Email/mobile no------------</h4>
        <br/>
        <TextField id="outlined-basic" label="Enter your mail  /  mobile no*" variant="outlined" />    
        <br/>
        <br/>
        <TextField id="outlined-basic" label="Password*" variant="outlined" />
        <br/>
        <br/>
        <br/>
        <FormControlLabel control={<Checkbox defaultChecked  size="small"  style={this.Checkbox} inputProps={{ 'aria-label': 'checkbox with small size' }} align="left"/>} label="Remember for 7 days"/>
        <Button color="primary">    <Link to="/Forget"> Forgot Password</Link>
        </Button>
        <br/>
        <br/>
        <br/>
        <Button variant="contained" href="#contained-buttons" style={this.Buttonstyle}> <Link to="/profile" style={this.Linkstyle}>SignIn</Link></Button>
        <br/>
        <br/>
        <Typography variant="h7" style={this.Typo3}>Don't have an account?</Typography>
        <Button className='signup'>
        <Link to="/Signup" >Signup</Link>
        </Button>
        </Card>
        </Grid>
      </div>
    )
  }
}