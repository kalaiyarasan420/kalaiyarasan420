import React from "react";
import { Link } from "react-router-dom";
import { Rating } from "@mui/material";
import { FormControlLabel } from "@mui/material";
import KMCHlogo from "../assets/kmchlogo.jpeg";
import ForwardIcon from '@mui/icons-material/Forward';
import "../styles/Rendered1.css";

function Rendered() {
  return (
    <div className="home" 
    // style={{ backgroundImage: `url(${BannerImage})`  }}
    >
      <div className="headerContainer">
      <div>
      
        <img className="photo" src={KMCHlogo} />
        
        <h3 className="address">99,Avanashi Road,<br></br>
        Coimbatore,<br></br>
        Tamil Nadu - 641014.
        </h3>
        <FormControlLabel control={<Rating name="half-rating" defaultValue={4.5} precision={0.5}/>} label="  4.5"/>
       
        </div>
        <div>
        <h2 className="overview"> <ForwardIcon/> Overview</h2>

        <p>⁜ Pioneered kidney transplant via steroid free methods</p>
        
<p>⁜ 20 well equipped operation theaters</p>
        <p>
        ⁜ More than 150 specialist doctors and more than 250 supporting professionals
</p>
<p>
⁜ NABH accredited hospital</p>
       
        <p>
        ⁜ ISO 27001:2005 certification</p>
      
        <p>
        ⁜ Round the clock emergency care and ambulance facility</p>
        </div>
        <div>
        <h2 className="overview"> <ForwardIcon/> Applicable Insurance</h2>
        <p>⁜ 24/7 Emergency Services</p>
          <p>⁜  Ambulance costs</p>
           <p>⁜ In-Patient Hospitalization costs</p>
           <p>⁜ Pre-Hospitalization costs</p>
           <p>⁜ Post-Hospitalization costs</p>
            <p>⁜ Day Care costs</p>
        </div>
        <a href="https://kmchhospitals.com/doctors-contact-numbers">
        
        <button> Make An Appointment
         
         </button>

      </a>
        <br></br>
        <br></br>
        <br></br>
      </div>
    </div>
  );
}

export default Rendered;