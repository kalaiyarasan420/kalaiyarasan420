import React, { Component } from 'react'
import { Link } from "react-router-dom";
// import { Typography, TextField, Grid, Avatar, RadioGroup,  FormControl, FormLabel, FormControlLabel, Radio, Button } from '@mui/material';
import { Typography, TextField, Grid, Button, Card ,FormControlLabel ,Checkbox } from '@mui/material';
import hakmglogo from "../assets/Logo.png"

export default class SignUp extends Component {
  // Grid={backgroundColor:"F"}
  Typo1 = { fontWeight: "50px", color: "grey" };
  Typo2 = { fontWeight: "bold", color: "black" };
  Typo = { fontWeight: "Bold", color: "#800080", margincenter: "200px" };
  Typo3 = { fontWeight: "Bold", color: "#800080", marginLeft: "200px" };
  Buttonstyle = {
    backgroundColor: "purple",
    width: "200px",
    height: "35px",
    marginLeft: "200px",
  };
  cardstyle = { padding: "45px", width: "600px", textAlign: "left" };
  avatarstyle = { color: "#800080" };
  img = { align: "left", width: "400px" };
  Checkbox = { color: "#800080" };
  Linkstyle = { color: "white" };
  render() {
    return (
      <div className="background">
        <Grid align="center" backgroundColor="#EF9FEF">
          <Card elevation={7} style={this.cardstyle}>
            <img src={hakmglogo} align="left" style={this.img} />
            <br />
            <br />
            <br />
            <br></br>
            <br></br>
            <br></br>
            <Typography variant="h4" align="left" style={this.Typo}>
              Set up your Account
            </Typography>
            {/* <Typography variant="h4" style={this.Typo}> </Typography> */}
            <br />
            <Typography variant="h6" style={this.Typo2}>
              Cover Insurance! Protect Family!
            </Typography>
            <br />
            <br />
            <TextField
              required
              id="standard-basic"
              label="First Name"
              variant="standard"
              type="text"
            />{" "}
            <TextField label="Last Name" variant="standard" type="text" />
            {/* <br/>
        <br/>    */}
            <br />
            <br />
            <TextField
              required
              id="standard-basic"
              label="Email/mobile no"
              variant="standard"
              type="text"
            />
            <br />
            <br />
            <TextField
              required
              id="standard-basic"
              label="Password"
              variant="standard"
              type="password"
            />
            <br />
            <Typography variant="h7" style={this.Typo1}>
              Must be atleast 8 characters
            </Typography>
            <br />
            <br />
            <TextField
              required
              id="standard-basic"
              label="Confirm Password"
              variant="standard"
              type="password"
            />
            <br />
            <br />
            <FormControlLabel
              control={
                <Checkbox
                  defaultChecked
                  size="small"
                  style={this.Checkbox}
                  inputProps={{ "aria-label": "checkbox with small size" }}
                />
              }
              label="Remember me for the next 7 days"
            />
            <br />
            <br />
            <br />
            <Button
              variant="contained"
              href="#contained-buttons"
              style={this.Buttonstyle}
            >
              <Link to="/" style={this.Linkstyle}>
                Create account
              </Link>
            </Button>
            <br />
            <br />
            <Typography variant="h7" style={this.Typo3}>
              Already a member?{" "}
            </Typography>
            <Button color="primary">
              <Link to="/login"> Sign In</Link>
            </Button>
          </Card>
        </Grid>
      </div>
    );
  }
}
