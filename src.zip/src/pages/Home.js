import { Button } from "@mui/material";
import { Link } from "react-router-dom";
import React from "react";
import Insurance from "../assets/Insurance1.png";
import EastIcon from '@mui/icons-material/East';
// import MultiplePizzas from "../assets/multiplePizzas.jpeg";
import "../styles/Home.css";

function About() {
  return (
    <div className="about">
      <div
        className="leftside"
        style={{ backgroundImage: `url(${Insurance})` }}
      >

      </div>

        <div className="rightSide">
        <h1>Health
        Assurance for
        Krank and
        Medical
        Guidances</h1>
        <h2>Your most appropriate Health insurance finder!</h2>
       
        <Link to="/profile"><h2 className="start">Start over here → </h2></Link>
    
      
<div/>

</div>
</div>
  );
}

export default About;