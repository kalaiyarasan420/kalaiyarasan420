import { Grid,TextField,Paper,Checkbox,Button,Typography ,FormControlLabel} from '@mui/material'
import React, { Component } from 'react'


export default class Forgetpassword extends Component {
    mystyle={margin:"0px",backgroundColor:"#EF9FEF"}
    cardstyle={padding:"40px",width:400, marginRight:"30px",textAlign:"left",height:500}
    Typography={color:"#800080" ,fontWeight:"Bold",align:"left"}
    Button={backgroundColor:"#800080",marginLeft:"100px"}
    Checkbox={color:"#800080"}
    TextField={backgroundcolor:"#800080"}
    img={width:200}
  render() {
    return (
      <div>
 <Grid align="center" style={this.mystyle}>
            <Paper elevation={7}  style={this.cardstyle}>
            <br/>
            {/* <img className='photo' src={pizzalogo} align="left" style={this.img} alt="not found"/> */}
            <br/>
            <br/>
            <br/>
            <br/>
            <Typography variant="h4" align="center" style={this.Typography}>Forgot Password</Typography>
            <br/>
            <br/>
            <TextField required id="standard" label="New Password"  variant="standard" type="password" autoComplete="current-password" style={this.TextField}/>
            <br/>
            <br/>
            <TextField  required id="standard-basic"  label="Confirm Password" variant="standard" type="password" autoComplete="current-password" />
            <br/>
            <br/>
            <br/>
            <FormControlLabel control={<Checkbox defaultChecked  size="small"  style={this.Checkbox} inputProps={{ 'aria-label': 'checkbox with small size' }}/>} label="Remember me for the next 7 days"/>
            <br/>
            <br/>
            <br/>
            <Button  variant="contained" align="center" style={this.Button}>Reset Password</Button>
            </Paper>
        </Grid>
      </div>
    )
  }
}