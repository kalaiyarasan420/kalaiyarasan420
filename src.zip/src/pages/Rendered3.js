import React from "react";
// import { Link } from "react-router-dom";
import { Rating } from "@mui/material";
import { FormControlLabel } from "@mui/material";
import KGLogo from "../assets/KGLogo.png";
import ForwardIcon from '@mui/icons-material/Forward';
// import "../styles/Rendered1.css";

function Rendered() {
  return (
    <div className="home" 
    // style={{ backgroundImage: `url(${BannerImage})`  }}
    >
      <div className="headerContainer">
      <div>
      
        <img className="photo" src={KGLogo} />
        <h3 className="address"> No. 5, Government Arts College Road, <br/>
        Coimbatore, Tamil Nadu 641 018.<br/>
        Contact : 04222219191 , 04224042121
        </h3>
        <FormControlLabel control={<Rating name="half-rating" defaultValue={4.4} precision={0.1}/>} label="  4.4"/>
        </div>
        <div>
        <h2 className="overview"> <ForwardIcon/> Overview</h2>
        <p>⁜ World's first 4D ultrasound system with wireless transducers was installed at KGH.</p>
        <p>⁜ Performed a rare heart surgery first time in medical history on a girl with 5 heart defects.</p>
        <p>⁜ More than 170 doctors are available.</p>
        <p>⁜ NABH & NABL accredited hospital.</p>
        <p>⁜ Recognised with the “Excellence in Teaching DNB Programs” Award from the Vice President of India & National Board.</p>
        <p>⁜ Round the clock emergency care and ambulance facility.</p>
        </div>
        <div>
        <h2 className="overview"> <ForwardIcon/> Applicable Insurance</h2>
          <p>⁜ 24/7 Emergency Services</p>
          <p>⁜ Ambulance costs</p>
          <p>⁜ In-Patient Hospitalization costs</p>
          <p>⁜ Pre-Hospitalization costs</p>
          <p>⁜ Post-Hospitalization costs</p>
          <p>⁜ Day Care costs</p>
        </div>
        <a href="https://pistha.kghospital.com/PISTHA/web/index.php?r=online-payment%2Findex">
        <button> Make An Appointment
         
         </button>

      </a>
        <br></br>
        <br></br>
        <br></br>
      </div>
    </div>
  );
}

export default Rendered;