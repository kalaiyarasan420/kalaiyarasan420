import React from "react";

import { Link } from "react-router-dom";
import Left from "../assets/enquiries.jpg";
import "../styles/Contact.css";

function Contact() {
  return (
    <div className="contact">
      <div
        className="leftSide"
        
        style={{ backgroundImage: `url(${Left})` }}>

      </div>
      <div className="rightSide">
        <h1> For Enquiry</h1>

        <form id="contact-form" method="POST">
          <label htmlFor="name">Full Name</label>
          <input name="name" placeholder="Enter full name..." type="text" />
          <label htmlFor="email">Email</label>
          <input name="email" placeholder="Enter email..." type="email" />
          <label htmlFor="email">Mobile Number</label>
          <input name="email" placeholder="Enter mobile..." type="number" />
          
          <label htmlFor="message">Message</label>
          <textarea
            rows="6"
            placeholder="Enter message..."
            name="message"
            required
          ></textarea>
          <button type="submit"> <Link to="/thanks"> Submit</Link></button>
        </form>
      </div>
    </div>
  );
}

export default Contact;