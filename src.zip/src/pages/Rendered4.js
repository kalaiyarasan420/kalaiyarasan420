import React from "react";
// import { Link } from "react-router-dom";
import { Rating } from "@mui/material";
import { FormControlLabel } from "@mui/material";
import KonguLogo1 from "../assets/KonguLogo1.png";
import ForwardIcon from '@mui/icons-material/Forward';
// import "../styles/Rendered1.css";

function Rendered() {
  return (
    <div className="home" 
    // style={{ backgroundImage: `url(${BannerImage})`  }}
    >
      <div className="headerContainer">
      <div>
      
        <img className="photo" src={KonguLogo1} />
        <h3 className="address"> 11th Street, Tatabad, Gandipuram, <br/>
        Coimbatore, Tamil Nadu 641012.<br/>
        Contact : 0422 431 6000 , +(91)-0422 2494363 
        </h3>
        <FormControlLabel control={<Rating name="half-rating" defaultValue={4.8} precision={0.1}/>} label="  4.8"/>
       
        </div>
        <div>
        <h2 className="overview"> <ForwardIcon/> Overview</h2>
        <p>⁜ KNH is a multi specialty hospital is located in Tatabad, Gandhipuram which is at heart of the city.</p>
        <p>⁜ Kongunad hospital has electronic case sheet, PACS system and mobile software for patient comfort and satisfaction.</p>
        <p>⁜ More than 100 qualified doctors are available.</p>
        <p>⁜ NABH Entry level certified hospital.</p>
        <p>⁜ KNH is very well designed for patient safety, employee safety and environment safety.</p>
        <p>⁜ Round the clock emergency care and ambulance facility.</p>
        </div>
        <div>
          <h2 className="overview"> <ForwardIcon/> Applicable Insurance</h2>
          <p>⁜ 24/7 Emergency Services</p>
          <p>⁜ Ambulance costs</p>
          <p>⁜ In-Patient Hospitalization costs</p>
          <p>⁜ Pre-Hospitalization costs</p>
          <p>⁜ Post-Hospitalization costs</p>
          <p>⁜ Day Care costs</p>
          </div>
        <a href="https://kongunad.com/make-an-appointment/">
        
        <button> Make An Appointment
         
         </button>

      </a>
        <br></br>
        <br></br>
        <br></br>
      </div>
    </div>
  );
}

export default Rendered;