import { Button,Typography ,} from '@mui/material'
import React, { Component } from 'react'


export default class thanks extends Component {
    mystyle={margin:"25px",backgroundColor:"#EF9FEF"}
    cardstyle={padding:"40px",width:400, marginRight:"30px",textAlign:"left",height:500}
    Typography={color:"#800080" ,fontWeight:"Bold",align:"left"}
    Button={backgroundColor:"#800080",marginLeft: "46%"}
    Checkbox={color:"#800080"}
    TextField={backgroundcolor:"#800080"}
    img={width:200}
  render() {
    return (
      <div>
 
            
            <br/>
            {/* <img className='photo' src={pizzalogo} align="left" style={this.img} alt="not found"/> */}
            <br/>
            <br/>
            <br/>
            <br/>
            <Typography variant="h4" align="center" style={this.Typography}>We will get back to you soon...</Typography>
            <br/>
            <br/>
            
            <br/>
            <br/>
            <br/>
            
            <Button  variant="contained" align="center" style={this.Button}>Thank You</Button>
            <br/>
            <br/>
            <br/>
           
        
      </div>
    )
  }
}