import React, { Component } from 'react'
import { Link } from "react-router-dom";

import { Typography, TextField, Grid, Avatar, Button, Card, NativeSelect, InputLabel, FormControl  } from '@mui/material';
 import "../styles/Profile.css";
export default class SignUp extends Component {
    mystyle={margin:"0px",backgroundColor:"#EF9FEF"}
    Typo={fontWeight:"Bold",color:"#800080"}
    Buttonstyle={backgroundColor:"#800080", width:"200px", height:"45px"}
    cardstyle={padding:"15px", width:"750px"}
    avatarstyle={color:"#800080"}
    genstyle={width: "200px"}
    Linkstyle={color:"white"}
  render() {
    return (
      <div className='background'>
        <Grid align="center" style={this.mystyle}>
        <Card  elevation={7} style={this.cardstyle} >
        {/* <img className='photo' src={pizzaLogo} alt="Not Found" align="left"/> */}
        <br/>
        <br/>
        <br/>
        <Avatar src="/static/images/avatar/1.jpg" style={this.avatarstyle} />
        <Typography variant="h4" style={this.Typo}>Profile</Typography>
        <TextField required id="standard-basic" label="Name" placeholder='Enter your Name' variant="standard" type="text" />
        <br/>
        <br/>
        <TextField required id="standard-basic" label="Email" placeholder='Enter your Mail ID' variant="standard" type="text" />
        <br/>
        <br/>
        <TextField required id="standard-basic" label="Mobile Number" placeholder='Enter your Mobile Number' variant="standard" type="number"/>
        <br/>
        <br/>
        <TextField required id="standard-basic" label="DOB" placeholder='DD/MM/YYYY' variant="standard" />
        <br/>
        <br/>
        {/* <TextField required id="standard-basic" label="Gender" placeholder='Enter your Gender' variant="standard" />
        <br/>
        <br/> */}
        <FormControl required style={this.genstyle}>
        <InputLabel variant="standard" htmlFor="uncontrolled-native">
          Gender
        </InputLabel>
        <NativeSelect
        //   defaultValue={"Your Gender"}
          inputProps={{
            name: 'Gen',
            id: 'uncontrolled-native',
          }}
        >
          <option value=""></option>
          <option>Male</option>
          <option>Female</option>
          <option>Other</option>
        </NativeSelect>
        </FormControl>
        <br/>
        <br/>
        <TextField id="standard-basic" label="Age" placeholder='Enter your Age' variant="standard" type="number"/>
        <br/>
        <br/>
        <TextField required id="standard-basic" label="Address" placeholder='Enter your Address' variant="standard" />
        <br/>
        <br/>
        <br/>
        <Button variant="contained" href="#contained-buttons" style={this.Buttonstyle}>    <Link to="/Search" style={this.Linkstyle}> Submit</Link></Button>
        </Card>
        </Grid>
      </div>
    )
  }
                }