import React, { Component } from 'react'
import { Grid,TextField,Paper,Button,Typography ,FormControl,NativeSelect,InputLabel,} from '@mui/material'
import { Link } from "react-router-dom";


export default class Getdetails extends Component {
    mystyle={margin:"0px",backgroundColor:"#EF9FEF"}
    cardstyle={padding:"80px",width:400, marginRight:"25px",height:700}
    Typography={color:"black" ,fontWeight:"Bold",align:"left", color:"#800080"}
    Button={backgroundColor:"#800080" }
    Checkbox={color:"#800080"}
    TextField={backgroundcolor:"#800080" }
    img={width:200, height:50,align:"left"}
    Linkstyle={color:"white"}
  render() {
    return (
      <div>
        <Grid align="center" style={this.mystyle}>
            <Paper elevation={7} align="left" style={this.cardstyle}>
            {/* <img className='photo' src={PizzaLogo} style={this.img} alt="not found"/> */}
            <br/>
            <br/>

            <Typography variant="h4" align="center" style={this.Typography}>Get Details</Typography>
            <br/>
            <br/>
            <Typography variant="h6" align="left" style={this.Typography}>Insurance Company Name</Typography>
           
            <FormControl required style={this.genstyle}>
        <InputLabel variant="standard" htmlFor="uncontrolled-native">
          Insurance
        </InputLabel>
        <NativeSelect
        //   defaultValue={"Your Gender"}
          inputProps={{
            name: 'Gen',
            id: 'uncontrolled-native',
          }}
        >
           <option value=""></option>
            <option>Star Health Insurance</option>
            <option>BajajAllianz General Insurance</option>
            <option>IFFCO - Tokio General Insurance</option>
            <option>Reliance General Insurance</option>
            <option>Other</option>

        </NativeSelect>
        </FormControl>
            <br/>
            <br/>
            
            <br/>
            <Typography variant="h6" align="left" style={this.Typography}>Insurance Type</Typography>
            <FormControl required style={this.genstyle}>
        <InputLabel variant="standard" htmlFor="uncontrolled-native">
          Insurance Type
        </InputLabel>
        <NativeSelect
        //   defaultValue={"Your Gender"}
        inputProps={{
          name: 'Gen',
          id: 'uncontrolled-native',
        }}
        >
<option value=""></option>
     
            <option>Health Insurance</option>

         
        </NativeSelect>
        </FormControl>         
           <br/>
            <br/>
            
            <br/>
            <Typography variant="h6" align="left" style={this.Typography}>Insurance ID</Typography>
            <br/>
            <TextField id="outlined-basic" label="Insurance ID" variant="filled" />
            <br/>
            <br/>
            <Typography variant="h6" align="left" style={this.Typography}>Location</Typography>
            <br/>
            <FormControl required style={this.genstyle}>
          <InputLabel variant="standard" htmlFor="uncontrolled-native">
            Location
          </InputLabel>
          <NativeSelect
          //   defaultValue={"Your Gender"}
          inputProps={{
            name: 'Gen',
            id: 'uncontrolled-native',
          }}
          >
            <option value=""></option>
            <option>Coimbatore</option>
          </NativeSelect>
          </FormControl>  
            {/* <TextField id="outlined-basic" label="Location" variant="filled" /> */}
            <br/>
            <br/>
            <Button  variant="contained" href="#contained-buttons" align="center"  style={this.Button} >
            <Link to="/Results" style={this.Linkstyle}> Results </Link>
            </Button>
            </Paper>
        </Grid>
      </div>
    )
  }
}
