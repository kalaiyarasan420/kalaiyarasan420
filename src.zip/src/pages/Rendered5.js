import React from "react";
import { Link } from "react-router-dom";
import { Rating } from "@mui/material";
import { FormControlLabel } from "@mui/material";
import MedwinLogo1 from "../assets/MedwinLogo1.png";
import ForwardIcon from '@mui/icons-material/Forward';
import "../styles/Rendered1.css";

function Rendered() {
  return (
    <div className="home" 
    // style={{ backgroundImage: `url(${BannerImage})`  }}
    >
      <div className="headerContainer">
      <div>
      
        <img className="photo" src={MedwinLogo1} />
        <h3 className="address"> No. 42, Opposite Stock Exchange, <br/> Near Alvernia School, Trichy Rd,<br/>
        Coimbatore, Tamil Nadu 641005.<br/>
        Contact :  0422-2315566 , +91 73737 16959 
        </h3>
        <FormControlLabel control={<Rating name="half-rating" defaultValue={4.7} precision={0.1}/>} label="  4.7"/>
       
       </div>
       <div>
       <h2 className="overview"> <ForwardIcon/> Overview</h2>

       <p>⁜ One of the top hospitals in Coimbatore offering advanced, reliable, accessible care at a reasonable price.</p>
       <p>⁜ One of the best ultrasound scan machines.</p>
       <p>⁜ This hospital fantastic ICU with 7 beds.</p>
       <p>⁜ This Hospital provide healthcare services in numerous significant treatment.</p>
       <p>⁜ NABL accredited hospital.</p>
       <p>⁜ 24/7 emergency care and ambulance facility.</p>
       </div>
       <div>
         <h2 className="overview"> <ForwardIcon/> Applicable Insurance</h2>
         <p>⁜ 24/7 Emergency Services</p>
         <p>⁜ Ambulance costs</p>
         <p>⁜ In-Patient Hospitalization costs</p>
         <p>⁜ Pre-Hospitalization costs</p>
         <p>⁜ Post-Hospitalization costs</p>
         <p>⁜ Day Care costs</p>
       </div>
       <a href="https://medwinhospital.in/#">
       
       <button> Make An Appointment
        
        </button>
        </a>
        <br></br>
        <br></br>
        <br></br>

    </div>
    </div>
  );
}

export default Rendered;