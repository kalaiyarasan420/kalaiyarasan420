import React from "react";
import { Link } from "react-router-dom";
import { Rating } from "@mui/material";
import { FormControlLabel } from "@mui/material";
import RamakrishnaLogo1 from "../assets/RamakrishnaLogo1.png";
import ForwardIcon from '@mui/icons-material/Forward';
import "../styles/Rendered1.css";

function Rendered() {
  return (
    <div className="home" >
    
      <div className="headerContainer">
      <div>
      
        <img className="photo" src={RamakrishnaLogo1} />
        <h3 className="address"> No: 395, Sarojini Naidu Road, Sidhapudur, <br/>
        Coimbatore, Tamil Nadu 641044.<br/>
        Contact : +91 4224 500 000 , +91 7970 108 108
        </h3>
        <FormControlLabel control={<Rating name="half-rating" defaultValue={4.0} precision={0.1}/>} label="  4.0"/>
       
        </div>
        <div></div>
        <h2 className="overview"> <ForwardIcon/> Overview</h2>

        <p>⁜ The original hospital has 1000 beds with trained staff.</p>
        <p>⁜ Provide holistic timely patient care.</p>
        <p>⁜ More than 800 qualified staffs.</p>
        <p>⁜ MTQUA Certification for International Standard of excellence for care and services.</p>
        <p>⁜ NABH accredited hospital.</p>
        <p>⁜ 24/7 emergency care and ambulance facility.</p>
        </div>
        <div>
          <h2 className="overview"> <ForwardIcon/> Applicable Insurance</h2>
          <p>⁜ 24/7 Emergency Services</p>
          <p>⁜ Ambulance costs</p>
          <p>⁜ In-Patient Hospitalization costs</p>
          <p>⁜ Pre-Hospitalization costs</p>
          <p>⁜ Post-Hospitalization costs</p>
          <p>⁜ Day Care costs</p>
        </div>
        <a href="https://www.sriramakrishnahospital.com/book-an-appointment/">
        
        <button> Make An Appointment
         
         </button>
         </a>
        <br></br>
        <br></br>
        <br></br>
      </div>

      

  );
}

export default Rendered;