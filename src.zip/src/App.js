import "./App.css";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import Home from "./pages/Home";
import Results from "./pages/Results";
import Search from "./pages/Searching";
import Profile from "./pages/Profile";
import KMCHpage from "./pages/Rendered1";
import ELCEpage from "./pages/Rendered2";
import KGpage from "./pages/Rendered3";
import KongunadPage from "./pages/Rendered4";
import MEDWINPage from "./pages/Rendered5";
import SNRPage from "./pages/Rendered6";
import Contact from "./pages/Enquiry";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import Forget from "./pages/Forget";
import Thanks from "./pages/Thanks";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";

function App() {
  return (
    <div className="App">
      <Router>
        <Navbar />
        <Switch>
          <Route path="/" exact component={Home} />
          <Route path="/results" exact component={Results} />
          <Route path="/search" exact component={Search} />
          <Route path="/profile" exact component={Profile} />
          <Route path="/login" exact component={Login} />
          <Route path="/signup" exact component={Signup} />
          <Route path="/forget" exact component={Forget} />
          <Route path="/thanks" exact component={Thanks} />
          <Route path="/KMCH" exact component={KMCHpage} />
          <Route path="/ELCE" exact component={ELCEpage} />
          <Route path="/KG" exact component={KGpage} />
          <Route path="/KN" exact component={KongunadPage} />
          <Route path="/MEDWIN" exact component={MEDWINPage} />
          <Route path="/SNR" exact component={SNRPage} />
          <Route path="/contact" exact component={Contact} />
        </Switch>
        <Footer />
      </Router>
    </div>
  );
}

export default App;